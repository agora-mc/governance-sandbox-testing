import { instances } from 'agora';

export async function probe() {
  const all = await instances.list();
  return {
    title: 'Publish probe v1.0.0',
    blocks: [{ type: 'stats', items: [{ label: 'Instances', value: String(all.length) }] }],
  };
}
